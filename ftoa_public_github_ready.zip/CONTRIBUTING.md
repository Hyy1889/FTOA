# Contributing

Thank you for your interest in improving this repository.

## Scope

This public release is intended to remain:

- runnable on a standard laptop
- disclosure-safe
- structurally aligned with the manuscript
- easy to inspect during peer review

## Recommended workflow

1. Fork the repository.
2. Create a feature branch.
3. Make small, reviewable commits.
4. Run the demo locally.
5. Open a pull request with a clear summary.

## Coding guidelines

- Target Python 3.10+
- Prefer explicit types
- Keep modules dependency-light
- Add comments when logic mirrors manuscript equations or assumptions
- Do not commit environment-specific secrets, IPs, or deployment credentials

## Pull request checklist

- [ ] Code runs with `python scripts/run_demo.py --config config/config.example.yaml`
- [ ] README remains accurate
- [ ] No private infrastructure details are exposed
- [ ] Configuration changes are documented
- [ ] New files include an appropriate license header if needed
