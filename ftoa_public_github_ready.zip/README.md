# FTOA Public Reproducible Package

This repository provides a **public, runnable, and disclosure-safe** reference implementation of the core FTOA pipeline described in the manuscript:

- Detection module
- Mitigation module
- Prevention module
- Controller orchestration
- YAML-based configuration
- Synthetic demo runner

## Important note about the baseline window

The manuscript reports that the baseline-learning duration was selected as **24 hours** as the best trade-off in the reported experiments. In this public package, the detection module is intentionally configured to use a **3-hour pretraining / warm-up window** because you requested that modification.

If you release this code alongside the paper, please explicitly state in the repository and in the rebuttal/response letter that:

> The public implementation uses a shortened 3-hour baseline-learning window for release convenience and faster reproducibility, whereas the manuscript's reported experiments used a 24-hour baseline window unless otherwise stated.

## Repository layout

```text
ftoa_public/
├── config/
│   └── config.example.yaml
├── ftoa/
│   ├── __init__.py
│   ├── config.py
│   ├── controller.py
│   ├── detection.py
│   ├── mitigation.py
│   ├── models.py
│   └── prevention.py
├── scripts/
│   └── run_demo.py
├── requirements.txt
└── README.md
```

## Quick start

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
python scripts/run_demo.py --config config/config.example.yaml
```

## What this package implements

### Detection

The detector maintains a sliding window over switch telemetry and computes an anomaly score from:

- remaining flow-table ratio
- Packet-In rate
- flow-key disorder / entropy

It supports:

- configurable baseline warm-up duration (default in this package: 3 hours)
- configurable 1-second detection window
- configurable consecutive alarm count
- dynamic feature weighting based on table utilization
- thresholding with `mu + k * sigma`

### Mitigation

Two mitigation paths are implemented:

- **Mitigation-A**: low-score but low-remaining-space path, with entropy-weighted switch prioritization
- **Mitigation-B**: attack-state per-flow scoring using packet rate, byte rate, duration, and relative switch averages

### Prevention

The prevention module applies per-port rate caps and assigns installation priority to elephant/high-frequency flows while penalizing suspicious flows.

## Disclosure-safe design

This public version avoids private infrastructure dependencies and does not expose any unpublished operational details that are unnecessary for reproducibility. It is intended to be:

- runnable on a laptop
- structurally faithful to the manuscript
- easy for reviewers to inspect
- easy to adapt to Mininet / Ryu / OVS integrations

## Suggested release statement for the paper or rebuttal

> To facilitate verification, we provide a publicly releasable, runnable reference implementation covering the core detection, mitigation, prevention, and controller orchestration logic. The public package omits environment-specific deployment artifacts and uses a shortened 3-hour detector warm-up window for ease of reproduction; the manuscript-reported experimental setting remains the reference configuration for the published results.



## Recommended files for the GitHub release

This repository now includes the common files expected in a public academic code release:

- `README.md`: overview, quick start, and release note
- `LICENSE`: permissive MIT license for the public package
- `CITATION.cff`: citation metadata recognized by GitHub
- `CONTRIBUTING.md`: lightweight contribution guidance
- `SECURITY.md`: disclosure guidance for security-related issues
- `CODE_OF_CONDUCT.md`: collaboration expectations
- `.gitignore`, `.gitattributes`, `.editorconfig`: repository hygiene files
- `pyproject.toml`: minimal package metadata
- `config/config.example.yaml`: public runnable default config with 3-hour warm-up
- `config/config.paper24h.yaml`: manuscript-aligned baseline-learning configuration

## GitHub upload checklist

1. Create a new GitHub repository.
2. Upload all files in this folder.
3. Set the default branch to `main`.
4. Add the manuscript title and repository description.
5. Replace the placeholder repository URL in `CITATION.cff`.
6. If needed, replace the generic copyright line in `LICENSE`.
7. Create the first release tag, for example `v0.1.0`.

## Run commands

Using the public 3-hour release config:

```bash
python scripts/run_demo.py --config config/config.example.yaml
```

Using the manuscript-aligned 24-hour config:

```bash
python scripts/run_demo.py --config config/config.paper24h.yaml
```
