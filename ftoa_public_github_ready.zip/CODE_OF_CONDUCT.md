# Code of Conduct

This project welcomes constructive, professional collaboration.

Participants are expected to:

- communicate respectfully
- provide actionable technical feedback
- avoid harassment, discrimination, and personal attacks
- focus discussion on reproducibility, correctness, and research value

Maintainers may remove comments or contributions that violate these expectations.
