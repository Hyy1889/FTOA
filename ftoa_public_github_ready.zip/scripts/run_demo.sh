#!/usr/bin/env bash
set -euo pipefail
python scripts/run_demo.py --config config/config.example.yaml
