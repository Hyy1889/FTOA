from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path
from typing import Dict, List

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from ftoa.config import load_config
from ftoa.controller import FTOAController
from ftoa.models import FlowRecord, SwitchProfile, SwitchTelemetry


def build_profiles(cfg: Dict) -> Dict[str, SwitchProfile]:
    cap = int(cfg['controller']['default_tcam_capacity'])
    base_rate = float(cfg['controller']['default_port_base_rate'])
    switch_ids = cfg['simulation']['switch_ids']

    profiles = {}
    for idx, sid in enumerate(switch_ids, start=1):
        profiles[sid] = SwitchProfile(
            switch_id=sid,
            betweenness_centrality=0.3 + 0.1 * idx,
            degree_centrality=0.2 + 0.08 * idx,
            downlink_bandwidth_sum=10.0 + idx * 5.0,
            critical_vlans=1 + idx,
            table_capacity=cap,
            port_base_rates={1: base_rate, 2: base_rate, 3: base_rate, 4: base_rate},
        )
    return profiles


def synthesize_flows(second: int, attack: bool, attack_strength: int) -> List[FlowRecord]:
    n_flows = 80 if not attack else 80 + attack_strength
    flows: List[FlowRecord] = []
    for i in range(n_flows):
        malicious = attack and i < attack_strength
        packets = random.randint(1, 4) if malicious else random.randint(20, 300)
        bytes_count = random.randint(60, 600) if malicious else random.randint(4_000, 200_000)
        duration = random.uniform(6.0, 12.0) if malicious else random.uniform(0.2, 4.0)
        proto = random.choice(['TCP', 'UDP', 'ICMP']) if malicious else random.choice(['TCP', 'UDP'])
        flow = FlowRecord(
            flow_id=f'f_{second}_{i}',
            src_ip=f'10.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}',
            dst_ip=f'192.168.{random.randint(0,10)}.{random.randint(1,254)}',
            src_port=random.randint(1024, 65535),
            dst_port=random.choice([80, 443, 53, 5001, 8080]),
            proto=proto,
            packets=packets,
            bytes_count=bytes_count,
            duration_sec=duration,
            ingress_port=random.randint(1, 4),
            idle_age=random.uniform(0.0, 10.0),
            hit_rate=packets / max(duration, 1e-6),
            average_packet_size=bytes_count / max(packets, 1),
            apit=random.uniform(0.0, 2.0),
        )
        flows.append(flow)
    return flows


def make_telemetry(cfg: Dict, profiles: Dict[str, SwitchProfile], second: int) -> Dict[str, SwitchTelemetry]:
    attack_start = int(cfg['simulation']['attack_start_second'])
    attack_end = int(cfg['simulation']['attack_end_second'])
    targets = set(cfg['simulation']['attack_target_switches'])

    telemetry_map: Dict[str, SwitchTelemetry] = {}
    for sid, profile in profiles.items():
        attack = sid in targets and attack_start <= second <= attack_end
        attack_strength = 120 if attack else 0
        flows = synthesize_flows(second, attack=attack, attack_strength=attack_strength)
        used = min(len(flows), profile.table_capacity)
        remaining = max(profile.table_capacity - used, 0)
        pkt_in_rate = random.uniform(20, 80) if not attack else random.uniform(350, 800)
        telemetry_map[sid] = SwitchTelemetry(
            switch_id=sid,
            timestamp=float(second),
            remaining_entries=remaining,
            table_capacity=profile.table_capacity,
            packet_in_rate=pkt_in_rate,
            active_flows=flows,
        )
    return telemetry_map


def main() -> None:
    parser = argparse.ArgumentParser(description='Run a public FTOA synthetic demo.')
    parser.add_argument('--config', required=True, help='Path to YAML config file.')
    args = parser.parse_args()

    cfg = load_config(args.config)
    random.seed(int(cfg.get('random_seed', 7)))

    profiles = build_profiles(cfg)
    controller = FTOAController(cfg, profiles)

    print('=== FTOA public demo ===')
    print(f"Detector warm-up window: {cfg['detection']['baseline_hours']} hour(s)")
    print('Note: this demo is synthetic and disclosure-safe.')

    total_seconds = int(cfg['simulation']['total_seconds'])
    for second in range(total_seconds):
        telemetry_map = make_telemetry(cfg, profiles, second)
        detection_results, prevention = controller.step(telemetry_map)

        if second % 20 == 0 or any(dr.alarm for dr in detection_results.values()):
            print(f'\n[t={second:03d}s]')
            for sid, dr in detection_results.items():
                limits = prevention.per_port_rate_limit[sid]
                limit_preview = ', '.join(f'p{p}:{v:.1f}' for p, v in sorted(limits.items())[:2])
                print(
                    f"  {sid}: score={dr.score:.3f}, thr={dr.threshold:.3f}, util={dr.utilization:.2f}, "
                    f"mode={dr.mitigation_mode}, alarm={dr.alarm}, limits=[{limit_preview}]"
                )


if __name__ == '__main__':
    main()
