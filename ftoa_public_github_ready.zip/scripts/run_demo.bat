@echo off
python scripts\run_demo.py --config config\config.example.yaml
