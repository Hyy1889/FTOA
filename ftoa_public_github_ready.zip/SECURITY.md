# Security Policy

This repository is a public research release and is not intended for production deployment.

## Reporting

Please do not publish security-sensitive findings as public issues when they could expose a real system.
Instead, contact the repository maintainer privately and include:

- affected file or module
- reproduction steps
- impact assessment
- suggested remediation

## Scope note

The demo code uses synthetic telemetry and avoids operational credentials, controller endpoints,
and environment-specific deployment artifacts.
