from __future__ import annotations

from dataclasses import dataclass
from math import log10
from typing import Dict, List, Set

from .models import DetectionResult, FlowRecord, MitigationResult, SwitchProfile, SwitchTelemetry


@dataclass
class RankedSwitch:
    switch_id: str
    weight: float


class Mitigator:
    def __init__(self, cfg: Dict):
        self.mitigation_a_top_fraction = float(cfg['mitigation_a_top_fraction'])
        self.mitigation_a_max_evictions_per_switch = int(cfg['mitigation_a_max_evictions_per_switch'])
        self.mitigation_b_score_threshold = float(cfg['mitigation_b_score_threshold'])
        self.min_flow_duration_seconds = float(cfg['min_flow_duration_seconds'])

    def apply(
        self,
        detection_results: Dict[str, DetectionResult],
        telemetry_map: Dict[str, SwitchTelemetry],
        profiles: Dict[str, SwitchProfile],
    ) -> MitigationResult:
        result = MitigationResult()

        mitigation_a_switches = [sid for sid, dr in detection_results.items() if dr.mitigation_mode == 'A']
        mitigation_b_switches = [sid for sid, dr in detection_results.items() if dr.mitigation_mode == 'B']

        if mitigation_a_switches:
            ranked = self._rank_switches_entropy_weighted(mitigation_a_switches, profiles)
            result.ranked_switches.extend([x.switch_id for x in ranked])
            n_target = max(1, int(len(ranked) * self.mitigation_a_top_fraction))
            for item in ranked[:n_target]:
                telemetry = telemetry_map[item.switch_id]
                evicted = self._evict_mouse_flows(telemetry.active_flows)
                result.evicted_flow_ids[item.switch_id] = [f.flow_id for f in evicted]
                result.suspicious_ports[item.switch_id] = {f.ingress_port for f in evicted}

        for sid in mitigation_b_switches:
            telemetry = telemetry_map[sid]
            suspicious = self._classify_attack_flows(telemetry.active_flows)
            result.evicted_flow_ids[sid] = [f.flow_id for f in suspicious]
            result.suspicious_ports[sid] = {f.ingress_port for f in suspicious}

        return result

    def _rank_switches_entropy_weighted(self, switch_ids: List[str], profiles: Dict[str, SwitchProfile]) -> List[RankedSwitch]:
        rows = []
        for sid in switch_ids:
            p = profiles[sid]
            rows.append(
                {
                    'switch_id': sid,
                    'betweenness': float(p.betweenness_centrality),
                    'degree': float(p.degree_centrality),
                    'bandwidth': float(p.downlink_bandwidth_sum),
                    'vlans': float(p.critical_vlans),
                }
            )

        features = ['betweenness', 'degree', 'bandwidth', 'vlans']
        normalized = {feat: self._minmax([row[feat] for row in rows]) for feat in features}
        weights = self._entropy_weights(normalized)

        ranked: List[RankedSwitch] = []
        for idx, row in enumerate(rows):
            score = sum(weights[feat] * normalized[feat][idx] for feat in features)
            ranked.append(RankedSwitch(switch_id=row['switch_id'], weight=score))
        ranked.sort(key=lambda x: x.weight, reverse=True)
        return ranked

    @staticmethod
    def _minmax(values: List[float]) -> List[float]:
        vmin, vmax = min(values), max(values)
        if abs(vmax - vmin) < 1e-12:
            return [1.0 for _ in values]
        return [(v - vmin) / (vmax - vmin) for v in values]

    @staticmethod
    def _entropy_weights(normalized: Dict[str, List[float]]) -> Dict[str, float]:
        import math

        m = len(next(iter(normalized.values())))
        eps = 1e-12
        d = {}
        for feat, vals in normalized.items():
            s = sum(vals) + eps
            probs = [(v + eps) / s for v in vals]
            e = -(1.0 / math.log(max(m, 2))) * sum(p * math.log(p) for p in probs)
            d[feat] = 1 - e
        denom = sum(d.values()) + eps
        return {feat: value / denom for feat, value in d.items()}

    def _evict_mouse_flows(self, flows: List[FlowRecord]) -> List[FlowRecord]:
        ranked = sorted(
            flows,
            key=lambda f: (
                f.bytes_count,
                f.packets,
                -f.duration_sec,
            ),
        )
        return ranked[: self.mitigation_a_max_evictions_per_switch]

    def _classify_attack_flows(self, flows: List[FlowRecord]) -> List[FlowRecord]:
        if not flows:
            return []

        total_packets = sum(f.packets for f in flows)
        total_bytes = sum(f.bytes_count for f in flows)
        avg_duration = sum(max(f.duration_sec, self.min_flow_duration_seconds) for f in flows) / len(flows)

        switch_pps = max(total_packets / max(avg_duration, self.min_flow_duration_seconds) / max(len(flows), 1), 1e-6)
        switch_bps = max((total_bytes * 8) / max(avg_duration, self.min_flow_duration_seconds) / max(len(flows), 1), 1e-6)

        suspicious: List[FlowRecord] = []
        for flow in flows:
            pkt_s = max(flow.packets / flow.safe_duration(), 1e-6)
            byte_s = max((flow.bytes_count * 8) / flow.safe_duration(), 1e-6)
            p_rel = log10(pkt_s) - log10(switch_pps)
            b_rel = log10(byte_s) - log10(switch_bps)
            long_low_profile = 1.0 if (flow.duration_sec >= 5.0 and flow.bytes_count < 1024) else 0.0
            score = max(0.0, -p_rel) + max(0.0, -b_rel) + long_low_profile
            if score >= self.mitigation_b_score_threshold:
                flow.suspicious = True
                suspicious.append(flow)
        return suspicious
