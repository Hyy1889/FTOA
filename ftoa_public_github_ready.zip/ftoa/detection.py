from __future__ import annotations

from collections import Counter, deque
from dataclasses import dataclass
from math import log2
from statistics import mean, pstdev
from typing import Deque, Dict, List

from .models import DetectionResult, SwitchTelemetry


@dataclass
class FeatureSnapshot:
    timestamp: float
    score: float
    remaining_ratio: float
    packet_in_rate: float
    entropy: float
    utilization: float


class OnlineDetector:
    """
    Public, runnable detector aligned with the paper's structure.

    Release note:
    - The paper reports 24 h baseline learning as the chosen experimental setting.
    - This public version allows changing it through config and can run with 3 h as requested.
    """

    def __init__(self, cfg: Dict):
        self.baseline_hours = float(cfg['baseline_hours'])
        self.sliding_window_seconds = int(cfg['sliding_window_seconds'])
        self.consecutive_alarm_windows = int(cfg['consecutive_alarm_windows'])
        self.threshold_sigma_k = float(cfg['threshold_sigma_k'])
        self.critical_utilization = float(cfg['critical_utilization'])
        self.guard_band_remaining_ratio = float(cfg['guard_band_remaining_ratio'])
        self.poll_interval_seconds = float(cfg.get('poll_interval_seconds', self.sliding_window_seconds))
        self.min_baseline_samples = int(cfg['min_baseline_samples'])
        self.suspend_threshold_update_during_alarm = bool(cfg['suspend_threshold_update_during_alarm'])

        self._baseline_scores: Dict[str, List[float]] = {}
        self._recent_flags: Dict[str, Deque[bool]] = {}
        self._history: Dict[str, Deque[FeatureSnapshot]] = {}
        self._threshold_frozen: Dict[str, bool] = {}

    def process(self, telemetry: SwitchTelemetry) -> DetectionResult:
        sid = telemetry.switch_id
        self._baseline_scores.setdefault(sid, [])
        self._recent_flags.setdefault(sid, deque(maxlen=self.consecutive_alarm_windows))
        self._history.setdefault(sid, deque(maxlen=max(self.sliding_window_seconds, 1)))
        self._threshold_frozen.setdefault(sid, False)

        entropy = self._compute_flow_entropy(telemetry)
        weights = self._dynamic_weights(telemetry.utilization)
        score = (
            weights['C'] * telemetry.remaining_ratio
            + weights['H'] * entropy
            + weights['P'] * self._normalize_packet_in_rate(telemetry.packet_in_rate)
        )

        threshold = self._current_threshold(sid)
        warmup_complete = self._is_warmup_complete(sid)
        score_exceeds = warmup_complete and score > threshold

        self._recent_flags[sid].append(score_exceeds)
        alarm = warmup_complete and len(self._recent_flags[sid]) == self.consecutive_alarm_windows and all(self._recent_flags[sid])

        if alarm and self.suspend_threshold_update_during_alarm:
            self._threshold_frozen[sid] = True
        elif not alarm:
            self._threshold_frozen[sid] = False

        if not self._threshold_frozen[sid]:
            self._update_baseline(sid, score)

        mitigation_mode = None
        if alarm:
            mitigation_mode = 'B'
        elif warmup_complete and telemetry.remaining_ratio < self.guard_band_remaining_ratio and score <= threshold:
            mitigation_mode = 'A'

        self._history[sid].append(
            FeatureSnapshot(
                timestamp=telemetry.timestamp,
                score=score,
                remaining_ratio=telemetry.remaining_ratio,
                packet_in_rate=telemetry.packet_in_rate,
                entropy=entropy,
                utilization=telemetry.utilization,
            )
        )

        return DetectionResult(
            switch_id=sid,
            timestamp=telemetry.timestamp,
            score=score,
            threshold=threshold,
            packet_in_rate=telemetry.packet_in_rate,
            remaining_ratio=telemetry.remaining_ratio,
            entropy=entropy,
            utilization=telemetry.utilization,
            alarm=alarm,
            mitigation_mode=mitigation_mode,
        )

    def _is_warmup_complete(self, switch_id: str) -> bool:
        baseline_needed = max(self.min_baseline_samples, int(self.baseline_hours * 3600 / max(self.poll_interval_seconds, 1)))
        return len(self._baseline_scores[switch_id]) >= baseline_needed

    def _update_baseline(self, switch_id: str, score: float) -> None:
        self._baseline_scores[switch_id].append(score)

    def _current_threshold(self, switch_id: str) -> float:
        scores = self._baseline_scores[switch_id]
        if len(scores) < 2:
            return 1.0
        mu = mean(scores)
        sigma = pstdev(scores)
        return mu + self.threshold_sigma_k * sigma

    @staticmethod
    def _normalize_packet_in_rate(packet_in_rate: float) -> float:
        # Lightweight bounded normalization for public release.
        return min(max(packet_in_rate / 1000.0, 0.0), 1.0)

    def _dynamic_weights(self, utilization: float) -> Dict[str, float]:
        """
        Follows the paper's idea: when utilization is low, rely more on entropy and Packet-In;
        when utilization rises beyond the critical point, emphasize remaining capacity.
        """
        u = min(max(utilization, 0.0), 1.0)
        if u < self.critical_utilization:
            return {'C': 0.20, 'H': 0.45, 'P': 0.35}
        if u < 0.60:
            return {'C': 0.45, 'H': 0.30, 'P': 0.25}
        return {'C': 0.60, 'H': 0.20, 'P': 0.20}

    def _compute_flow_entropy(self, telemetry: SwitchTelemetry) -> float:
        flows = telemetry.active_flows
        if not flows:
            return 0.0

        src_ip_counter = Counter(flow.src_ip for flow in flows)
        port_pair_counter = Counter((flow.src_port, flow.dst_port) for flow in flows)
        proto_counter = Counter(flow.proto for flow in flows)

        hdip = self._normalized_entropy_from_counter(src_ip_counter)
        hdpo = self._normalized_entropy_from_counter(port_pair_counter)
        hdpr = self._normalized_entropy_from_counter(proto_counter)
        return (hdip + hdpo + hdpr) / 3.0

    @staticmethod
    def _normalized_entropy_from_counter(counter: Counter) -> float:
        total = sum(counter.values())
        if total <= 0 or len(counter) <= 1:
            return 0.0
        ent = 0.0
        for count in counter.values():
            p = count / total
            if p > 0:
                ent -= p * log2(p)
        return ent / max(log2(len(counter)), 1e-6)
