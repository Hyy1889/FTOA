from __future__ import annotations

from typing import Dict, List

from .models import FlowRecord, MitigationResult, PreventionDecision, SwitchProfile, SwitchTelemetry


class PreventionModule:
    def __init__(self, cfg: Dict):
        self.alpha = float(cfg['alpha'])
        self.elephant_byte_threshold = int(cfg['elephant_byte_threshold'])
        self.elephant_avg_pkt_threshold = float(cfg['elephant_avg_pkt_threshold'])
        self.high_freq_hit_rate_threshold = float(cfg['high_freq_hit_rate_threshold'])
        self.attack_penalty_weight = float(cfg['attack_penalty_weight'])
        self.elephant_weight = float(cfg['elephant_weight'])
        self.freq_weight = float(cfg['freq_weight'])
        self.blocked_port_decay = float(cfg['blocked_port_decay'])
        self.port_attack_score: Dict[str, Dict[int, float]] = {}

    def apply(
        self,
        telemetry_map: Dict[str, SwitchTelemetry],
        profiles: Dict[str, SwitchProfile],
        mitigation_result: MitigationResult,
    ) -> PreventionDecision:
        decision = PreventionDecision()

        for sid, telemetry in telemetry_map.items():
            profile = profiles[sid]
            suspicious_ports = mitigation_result.suspicious_ports.get(sid, set())
            port_scores = self.port_attack_score.setdefault(sid, {})

            per_port_limit: Dict[int, float] = {}
            for port, base_rate in profile.port_base_rates.items():
                old_score = port_scores.get(port, 1.0)
                updated_score = old_score * self.blocked_port_decay
                if port in suspicious_ports:
                    updated_score = min(old_score + 0.5, 3.0)
                port_scores[port] = updated_score

                beta = 1.0 / max(updated_score, 1.0)
                rmax = self.alpha * (1 - telemetry.utilization) * base_rate * beta
                per_port_limit[port] = max(rmax, 1.0)

            prioritized = sorted(
                telemetry.active_flows,
                key=lambda f: self._priority_score(f),
                reverse=True,
            )

            decision.per_port_rate_limit[sid] = per_port_limit
            decision.prioritized_flow_ids[sid] = [f.flow_id for f in prioritized]

        return decision

    def _priority_score(self, flow: FlowRecord) -> float:
        elephant = self.elephant_weight if self._is_elephant(flow) else 0.0
        freq = self.freq_weight if flow.hit_rate >= self.high_freq_hit_rate_threshold else 0.0
        attack = self.attack_penalty_weight if flow.suspicious else 0.0
        return elephant + freq - attack

    def _is_elephant(self, flow: FlowRecord) -> bool:
        return (
            flow.bytes_count >= self.elephant_byte_threshold
            or flow.average_packet_size >= self.elephant_avg_pkt_threshold
            or flow.apit >= 1.0
        )
