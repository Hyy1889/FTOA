from __future__ import annotations

from typing import Dict

from .detection import OnlineDetector
from .mitigation import Mitigator
from .models import DetectionResult, PreventionDecision, SwitchProfile, SwitchTelemetry
from .prevention import PreventionModule


class FTOAController:
    def __init__(self, config: Dict, profiles: Dict[str, SwitchProfile]):
        self.config = config
        self.profiles = profiles
        self.detector = OnlineDetector(config['detection'])
        self.mitigator = Mitigator(config['mitigation'])
        self.prevention = PreventionModule(config['prevention'])

    def step(self, telemetry_map: Dict[str, SwitchTelemetry]) -> tuple[Dict[str, DetectionResult], PreventionDecision]:
        detection_results: Dict[str, DetectionResult] = {}
        for sid, telemetry in telemetry_map.items():
            detection_results[sid] = self.detector.process(telemetry)

        mitigation_result = self.mitigator.apply(detection_results, telemetry_map, self.profiles)
        prevention_decision = self.prevention.apply(telemetry_map, self.profiles, mitigation_result)
        return detection_results, prevention_decision
