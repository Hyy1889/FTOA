from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Set


@dataclass
class FlowRecord:
    flow_id: str
    src_ip: str
    dst_ip: str
    src_port: int
    dst_port: int
    proto: str
    packets: int
    bytes_count: int
    duration_sec: float
    ingress_port: int
    idle_age: float = 0.0
    hit_rate: float = 0.0
    average_packet_size: float = 0.0
    apit: float = 0.0
    suspicious: bool = False

    def safe_duration(self) -> float:
        return max(self.duration_sec, 1e-6)


@dataclass
class SwitchTelemetry:
    switch_id: str
    timestamp: float
    remaining_entries: int
    table_capacity: int
    packet_in_rate: float
    active_flows: List[FlowRecord] = field(default_factory=list)

    @property
    def utilization(self) -> float:
        used = max(self.table_capacity - self.remaining_entries, 0)
        return min(max(used / max(self.table_capacity, 1), 0.0), 1.0)

    @property
    def remaining_ratio(self) -> float:
        return min(max(self.remaining_entries / max(self.table_capacity, 1), 0.0), 1.0)


@dataclass
class SwitchProfile:
    switch_id: str
    betweenness_centrality: float
    degree_centrality: float
    downlink_bandwidth_sum: float
    critical_vlans: int
    table_capacity: int
    port_base_rates: Dict[int, float]


@dataclass
class DetectionResult:
    switch_id: str
    timestamp: float
    score: float
    threshold: float
    packet_in_rate: float
    remaining_ratio: float
    entropy: float
    utilization: float
    alarm: bool
    mitigation_mode: str | None


@dataclass
class MitigationResult:
    suspicious_ports: Dict[str, Set[int]] = field(default_factory=dict)
    evicted_flow_ids: Dict[str, List[str]] = field(default_factory=dict)
    ranked_switches: List[str] = field(default_factory=list)


@dataclass
class PreventionDecision:
    per_port_rate_limit: Dict[str, Dict[int, float]] = field(default_factory=dict)
    prioritized_flow_ids: Dict[str, List[str]] = field(default_factory=dict)
